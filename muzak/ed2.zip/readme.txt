September 6, 1999

Wow, another Ed skin so quickly! WhenI saw this picture I just couldn't
resist! She looks so.. angelic here ^^ I think it's the lack of a nose
and the little eyelashes that do the trick ^_^ Anyway, this skin comes 
with a non-functioning ed skin as well. it's in the zip file here, and 
is called 'eqmain1.bmp'. To replace the eq skin with the buttons on it 
with the non-functioning one, simply change the name of the eqmain1.bmp
to eqmain.bmp :)

Emi
MagicalEmi@aol.com
http://fly.to/Emichan